<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!--//Задача: сделать рабочий конвертер валют, два поля и кнопка "сконвертировать"
Вывод сделать ниже.-->
<form action="php/script.php" method="POST">
    <input placeholder="Рубли" type="text" name="rub">
    <input placeholder="Доллары" type="text" name="dol">
    <button type="submit">Конвертировать</button>
</form>


</body>
</html>